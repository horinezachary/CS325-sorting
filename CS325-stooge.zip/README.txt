--stoogesort.cpp--
This program sorts using a 2/3 sorting method.
Create a file data.txt with the data to be sorted in the same folder and this program will output the sorted list to a file called insert.out

--stoogetime.cpp--
This program sorts using a 2/3 sorting method.
This program generates large sets of random numbers outputs the time it takes to sort them to the command line.
