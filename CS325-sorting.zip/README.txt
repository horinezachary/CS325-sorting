--insertsort.cpp--
Create a file data.txt with the data to be sorted in the same folder and this program will output the sorted list to a file called insert.out

--inserttime.cpp--
This program generates large sets of random numbers outputs the time it takes to sort them to the command line.

--mergesort.cpp--
This program is faster than insert sort.
Create a file data.txt with the data to be sorted in the same folder and this program will output the sorted list to a file called insert.out

--mergetime.cpp--
This program is faster than insert sort.
This program generates large sets of random numbers outputs the time it takes to sort them to the command line.

